const userModel = require('../models/user');
const mongoose = require('mongoose');
const bcrypt = require("bcrypt");

exports.getSignupForm = (req, res) => {

    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    // const user=req.session.isAdmin ? req.session.isAdmin :false;
   
        res.render('signup', {
            pageTitle: 'Create our account',
            isAuthenticated: isAuthenticated,
            // user:user

        });
    
}




exports.postSignupForm = async(req, res) => {
   
   const hashpassword=await bcrypt.hash(req.body.password,12);

    const model = new userModel({
      
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: hashpassword,
        
       
    });
   
    
    model.save().then(addedCustomer => {
        res.redirect('/accounts/signin');
    });
}

exports.getSigninForm = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    // const user=req.session.isAdmin ? req.session.isAdmin :false;
    res.render('signin', {
        pageTitle: 'Login to your account',
        isAuthenticated: isAuthenticated,
            // user:user
    });
}

exports.postSigninForm = async (req, res) => {
 
    const Password = req.body.password;
     userModel.findOne({
        email: req.body.email,
    })
     
     .then (user => {
        if(user) {

     bcrypt.compare(Password, user.password,(err, data) =>{
   if (err) throw err
console.log(data);
//if both match than you can do anything
if (!data) {

    res.redirect('/accounts/signin');
}

            })
           




         
            const admin = (user.role =='admin') ? true : false;
         
            req.session.isLoggedIn = true,
            req.session.isAdmin = admin;
            req.session.user = user

            res.redirect('/');

        } else {
            res.redirect('/account/signin');
        }
    })

  
}


exports.postLogout = (req, res, next) => {
    req.session.destroy(err => {
      console.log(err);
      res.redirect('/');
    });
  };


